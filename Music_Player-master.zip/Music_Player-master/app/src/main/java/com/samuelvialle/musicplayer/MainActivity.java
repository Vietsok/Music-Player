package com.samuelvialle.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    /**
     * #000 Commencer par la création du readme.md pour l'affichage
     * d'informations directement dans github. Pour le créer :
     * Changer la vue Android par la vue Project de l'explorateur
     * Créer le fichier à la racine de votre package
     */

    private static final String TAG = "Music Player";

    /**
     * #1 Ajouter du son en automatique : Création de la variable globale du MediaPlayer
     **/
    MediaPlayer mediaPlayer = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        /** #1.1 Ajouter du son en automatique : Assignation du fichier et lancement du mediaplayer **/
//        mediaPlayer = MediaPlayer.create(this, R.raw.sound);
//        // Lancement du mediaplayer
//        mediaPlayer.start();
        /** #2 // #3 Gestion de la récupération du morceau à lire **/
        mediaPlayer = MediaPlayer.create(this, R.raw.sound);

        /** #3.1 Appel de la méthode position **/
        position();

        /** #4.1 Appel de la méthode volume **/
        volume();

    }

    /**
     * #2.1 La méthode Play
     **/
    public void play(View view) {
        mediaPlayer.start();
    }

    /**
     * #2 La méthode Play
     **/
    public void pause(View view) {
        mediaPlayer.pause();
    }

    /**
     * #3 La méthode pour la seekbarPosition
     **/
    public void position() { // Ne pas oublier de placer cette méthode dans le onCreate
        // Association du widget seekBar au code
        SeekBar sbPosition = findViewById(R.id.sbPosition);
        // Définition de la valeur max de la durée du morceau
        sbPosition.setMax(mediaPlayer.getDuration());
        /** Partie 1 la gestion du déplacement du curseur par l'utilisateur **/
        // Ajout du listener pour agir sur le morceau et faire avancer la progression lors de la lecture
        sbPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Ici on mettra la durée plus tard mais on peuxt l'afficher dans les logs en attendant
                Log.i(TAG, "Position dans le morceau : " + Integer.toString(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // On passe en pause le morceau pour éviter d'entendre le son lors du déplacement du curseur
                pause(sbPosition);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // On relance la lecture lorsque l'utilisateur relache le curseur
                play(sbPosition);
                // On récupère la position lors du relachement pour éviter l'écho lors de l'écoute
                mediaPlayer.seekTo(sbPosition.getProgress());
            }
        });
        /** Partie 2 la gestion du déplacement du curseur en fonction de la lecture **/
        // Ajout d'un Timer
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                // Déplacement automatique du curseur de la seekBar position
                sbPosition.setProgress(mediaPlayer.getCurrentPosition());
            }
        // Ajout du délai pour décaler le départ de la routine, ici 0, on commence en même temps que le morceau
        }, 0,
                // Ajout de l'intervalle de rafraîchissement, ici toutes les 300ms
                300);
    }

    /** #3 La méthode pour la seekbarPosition **/
    public void volume(){ // Ne pas oublier de placer cette méthode dans le onCreate
        // Association du widget seekBar au code
        SeekBar sbVolume = findViewById(R.id.sbVolume);
        // Initialisation du manager en tant que service, ne pas oublier le cast !
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        // Définition du volumeMax en fonction du terminal utilisé
        int volumeMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        // Valorisation de cette valeur à notre seekBar
        sbVolume.setMax(volumeMax);

        // Définition du volume courant (celui réglé sur le terminal au démarrage de l'app)
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        // Ajustement de la position du curseur
        sbVolume.setProgress(currentVolume);

        // Ajout du listener pour la gestion de la seekBar
        sbVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Affichage dans les log du Volume
                Log.i(TAG, "Volume : " + Integer.toString(progress));
                // Association de la position du curseur de la seekbar en fonction du volume
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}